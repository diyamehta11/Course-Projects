function diffusion_analysis_combined()
    % Define the grid sizes
    grids = [41, 81, 161];

    % Initialize arrays to store run times, residuals, and iterations
    run_times_gs = zeros(length(grids), 1);
    run_times_lb = zeros(length(grids), 1);
    residuals_gs = cell(length(grids), 1);
    residuals_lb = cell(length(grids), 1);
    iterations_gs = zeros(length(grids), 1);
    iterations_lb = zeros(length(grids), 1);

    for idx = 1:length(grids)
        nx = grids(idx);
        ny = grids(idx);
        dx = 1.0 / (nx - 1);
        dy = 1.0 / (ny - 1);

        % Start timing for Gauss-Seidel method
        tic;
        [phi_gs, residual_gs, num_iterations_gs] = diffusion_equation_gauss_seidel(nx, ny, dx, dy);
        run_times_gs(idx) = toc;

        % Store residuals and iterations
        residuals_gs{idx} = residual_gs;
        iterations_gs(idx) = num_iterations_gs;

        % Start timing for Line-by-Line method
        x = linspace(0, 1, nx);
        y = linspace(0, 1, ny);
        [X, Y] = meshgrid(x, y);
        delta_sq = dx^2; % Assume square grid

        % Initialize the solution array
        phi_lb = zeros(nx, ny);

        % Define the source term matrix
        S = 50000 * exp(-50 * ((1 - X).^2 + Y.^2)) .* (100 * ((1 - X).^2 + Y.^2) - 2);

        % Apply boundary conditions
        phi_lb(:, 1) = 500 * exp(-50 * (1 + Y(:, 1).^2));
        phi_lb(:, end) = 100 * (1 - Y(:, end)) + 500 * exp(-50 * Y(:, end).^2);
        phi_lb(1, :) = 100 * X(1, :) + 500 * exp(-50 * (1 - X(1, :)).^2);
        phi_lb(end, :) = 500 * exp(-50 * ((1 - X(end, :)).^2 + 1));

        tic;
        [phi_lb, residual_lb, num_iterations_lb] = row_sweep(phi_lb, S, delta_sq);
        run_times_lb(idx) = toc;

        % Store residuals and iterations
        residuals_lb{idx} = residual_lb;
        iterations_lb(idx) = num_iterations_lb;

        % Plot numerical solution (Line-by-Line)
        figure;
        contourf(linspace(0, 1, nx), linspace(0, 1, ny), phi_lb, 20);
        colorbar;
        title(['Line-by-Line Numerical Solution for ', num2str(nx), 'x', num2str(ny), ' Grid']);
        xlabel('x');
        ylabel('y');
    end

    % Plot Residual vs Number of Iterations for 161x161 grid
    figure;
    hold on;
    if ~isempty(residuals_gs{3})
        plot(1:length(residuals_gs{3}), residuals_gs{3}, 'red', 'DisplayName', 'Gauss-Seidel');
    end
    if ~isempty(residuals_lb{3})
        plot(1:length(residuals_lb{3}), residuals_lb{3}, 'blue', 'DisplayName', 'Line-by-Line');
    end
    xlabel('Iteration Number');
    ylabel('Residual');
    title('Residual vs Number of Iterations (161x161 Grid)');
    legend('show');
    hold off;

    % Plot CPU run time vs total number of grid points (Line-by-Line)
    total_points = grids.^2;
    figure;
    plot(total_points, run_times_lb, '-o');
    xlabel('Total Number of Grid Points');
    ylabel('CPU Run Time (seconds)');
    title('CPU Run Time vs Total Number of Grid Points (Line-by-Line)');

    % Plot CPU run time vs total number of grid points (Line-by-Line)
    total_points = grids.^2;
    figure;
    plot(total_points, run_times_gs, '-o');
    xlabel('Total Number of Grid Points');
    ylabel('CPU Run Time (seconds)');
    title('CPU Run Time vs Total Number of Grid Points (Gauss-Seidel)');
end

% Gauss-Seidel function remains the same as before
function [phi, residuals, num_iterations] = diffusion_equation_gauss_seidel(nx, ny, dx, dy)
    x = linspace(0, 1, nx);
    y = linspace(0, 1, ny);
    [X, Y] = meshgrid(x, y);

    % Initialize the solution array
    phi = zeros(nx, ny);    % Create a 2D grid of nodes

    residuals = []; % Initialize residuals array

    % Apply boundary conditions
    phi(:, 1) = 500 * exp(-50 * (1 + Y(:, 1).^2));
    phi(:, end) = 100 * (1 - Y(:, end)) + 500 * exp(-50 * (Y(:, end).^2));
    phi(1, :) = 100 * x .* (1 - Y(1, :)) + 500 * exp(-50 * ((1 - x).^2));
    phi(end, :) = 500 * exp(-50 * ((1 - x).^2 + 1));

    % Gauss-Seidel iterative method parameters
    max_iter = 100000;
    tol = 1e-6;

    % Iterate using Gauss-Seidel method
    for iter = 1:max_iter
        phi_old = phi;

        for i = 2:nx-1
            for j = 2:ny-1
                S_phi = 50000 * exp(-50 * ((1 - X(i, j))^2 + Y(i, j)^2)) * (100 * ((1 - X(i, j))^2 + Y(i, j)^2) - 2);
                phi(i, j) = (1/(2/dx^2 + 2/dy^2)) * ...
                            ((phi(i+1, j) + phi(i-1, j)) / dx^2 + ...
                             (phi(i, j+1) + phi(i, j-1)) / dy^2 - S_phi);
            end
        end

        % Calculate the residual
        residual = max(max(abs(phi - phi_old)));
        residuals = [residuals, residual];

        % Check for convergence
        if residual < tol
            num_iterations = iter;
            return;
        end
    end

    num_iterations = max_iter; % If max iterations reached without convergence
    disp('Gauss-Seidel method did not converge within the maximum number of iterations.');
end

function [phi_new, residuals, num_iterations] = row_sweep(phi_old, source, delta_sq, tol, max_iter)
    if nargin < 4
        tol = 1e-6;
    end
    if nargin < 5
        max_iter = 100000;
    end

    n = size(phi_old, 1); % Size of the grid
    residuals = [];
    sub_dia = ones(n-3, 1);
    super_dia = sub_dia;
    main_dia = -4 * ones(n-2, 1);

    for iter = 1:max_iter
        phi_new = phi_old;

        % Row-wise sweep
        for row = 2:n-1
            b = zeros(n-2, 1);

            % Fill RHS for the first interior column (j = 2)
            b(1) = source(row, 2) * delta_sq - phi_old(row-1, 2) - phi_old(row+1, 2) - phi_old(row, 1);

            % Fill RHS for the interior columns (j = 3 to n-2)
            for col = 3:n-2
                b(col-1) = source(row, col) * delta_sq - phi_old(row-1, col) - phi_old(row+1, col);
            end

            % Fill RHS for the last interior column (j = n-1)
            b(n-2) = source(row, n-1) * delta_sq - phi_old(row-1, n-1) - phi_old(row+1, n-1) - phi_old(row, n);

            % Solve the tridiagonal system for this row using TDMA
            row_new = tdma_solver(sub_dia, main_dia, super_dia, b);

            % Update the solution for this row
            phi_new(row, 2:n-1) = row_new';
        end

        % Calculate residual
        residual = max(abs(phi_new(:) - phi_old(:)));
        residuals = [residuals, residual];

        % Convergence check based on residual
        if residual < tol
            num_iterations = iter;
            return;
        end

        % Update the old solution
        phi_old = phi_new;
    end

    num_iterations = max_iter; % If max iterations reached without convergence
    disp('Line-by-Line method did not converge within the maximum number of iterations.');
end

function solution = tdma_solver(a, b, c, d)
    n = length(d);  % Length of the right-hand side vector

    % Forward sweep
    for i = 2:n
        w = a(i-1) / b(i-1);
        b(i) = b(i) - w * c(i-1);
        d(i) = d(i) - w * d(i-1);
    end

    % Back substitution
    solution = zeros(n, 1);
    solution(n) = d(n) / b(n);

    for i = n-1:-1:1
        solution(i) = (d(i) - c(i) * solution(i+1)) / b(i);
    end
end

function diffusion_analysis()
    % Define the grid sizes
    grids = [41,81,161];
    
    % Initialize arrays to store run times, residuals, and iterations
    run_times = zeros(length(grids), 1);
    residuals = cell(length(grids), 1);
    iterations = zeros(length(grids), 1);
    
    for idx = 1:length(grids)
        nx = grids(idx);
        ny = grids(idx);
        dx = 1.0 / (nx - 1);
        dy = 1.0 / (ny - 1);

        % Start timing
        tic;

        % Solve the diffusion equation using Gauss-Seidel method and get residuals and iterations
        [phi, residual, num_iterations] = diffusion_equation_gauss_seidel(nx, ny, dx, dy);

        % Record run time
        run_times(idx) = toc;

        % Store residuals and iterations
        residuals{idx} = residual;
        iterations(idx) = num_iterations;

        % Compute the analytical solution for comparison
        [X, Y] = meshgrid(linspace(0, 1, nx), linspace(0, 1, ny));
        phi_analytical = analytical_solution(X, Y);

        % Plot numerical solution
        figure;
        contourf(linspace(0, 1, nx), linspace(0, 1, ny), phi, 20);
        colorbar;
        title(['Numerical Solution for ', num2str(nx), 'x', num2str(ny), ' Grid']);
        xlabel('x');
        ylabel('y');
            
        % Plot analytical solution
        figure;
        contourf(linspace(0, 1, nx), linspace(0, 1, ny), phi_analytical, 20);
        colorbar;
        title(['Analytical Solution for ', num2str(nx), 'x', num2str(ny), ' Grid']);
        xlabel('x');
        ylabel('y');
    end

    % Plot CPU run time vs total number of grid points
    total_points = grids.^2;
    figure;
    plot(total_points, run_times, '-o');
    xlabel('Total Number of Grid Points');
    ylabel('CPU Run Time (seconds)');
    title('CPU Run Time vs Total Number of Grid Points');
    
    % Plot Residual vs Number of Iterations
    figure;
    hold on;
    for idx = 1:length(grids)
        plot(1:length(residuals{idx}), residuals{idx}, '-o', 'DisplayName', [num2str(grids(idx)) 'x' num2str(grids(idx)) ' Grid']);
    end
    xlabel('Iteration Number');
    ylabel('Residual');
    title('Residual vs Number of Iterations for Different Grid Sizes');
    legend('show');
    hold off;
end

function [phi, residuals, num_iterations] = diffusion_equation_gauss_seidel(nx, ny, dx, dy)
    % Create a 2D grid of nodes
    x = linspace(0, 1, nx);
    y = linspace(0, 1, ny);
    [X, Y] = meshgrid(x, y);

    % Initialize the solution array
    phi = zeros(nx, ny);
    residuals = []; % Initialize residuals array

    % Apply boundary conditions
    phi(:, 1) = 500 * exp(-50 * (1 + Y(:, 1).^2));
    phi(:, end) = 100 * (1 - Y(:, end)) + 500 * exp(-50 * (Y(:, end).^2));
    phi(1, :) = 100 * x .* (1 - Y(1, :)) + 500 * exp(-50 * ((1 - x).^2));
    phi(end, :) = 500 * exp(-50 * ((1 - x).^2 + 1));

    % Gauss-Seidel iterative method parameters
    max_iter = 100000;
    tol = 1e-6;

    % Iterate using Gauss-Seidel method
    for iter = 1:max_iter
        phi_old = phi;

        for i = 2:nx-1
            for j = 2:ny-1
                S_phi = 50000 * exp(-50 * ((1 - X(i, j))^2 + Y(i, j)^2)) * (100 * ((1 - X(i, j))^2 + Y(i, j)^2) - 2);
                phi(i, j) = (1/(2/dx^2 + 2/dy^2)) * ((phi(i+1, j) + phi(i-1, j)) / dx^2 + (phi(i, j+1) + phi(i, j-1)) / dy^2 - S_phi);
            end
        end

        % Calculate the residual
        residual = max(max(abs(phi - phi_old)));
        residuals = [residuals, residual];

        % Check for convergence
        if residual < tol
            num_iterations = iter;
            return;
        end
    end

    num_iterations = max_iter; % If max iterations reached without convergence
    disp('Gauss-Seidel method did not converge within the maximum number of iterations.');
end

function phi_analytical = analytical_solution(X, Y)
    phi_analytical = 500 * exp(-50 * ((1 - X).^2 + Y.^2)) + 100 * X .* (1 - Y);
end


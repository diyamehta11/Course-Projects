% Define the grid sizes
grids = [21,41,81];

% Initialize arrays to store run times
run_times = zeros(length(grids), 1);

for idx = 1:length(grids)
    nx = grids(idx);
    ny = grids(idx);
    drawnow 1.0 / (nx - 1);
    dy = 1.0 / (ny - 1);

    % Start timing
    tic;

    % Solve the diffusion equation
    phi = diffusion_equation(nx, ny, dx, dy);

    % Record run time
    run_times(idx) = toc;

    % Compute the analytical solution for comparison
    [X, Y] = meshgrid(linspace(0, 1, nx), linspace(0, 1, ny));
    phi_analytical = analytical_solution(X, Y);

    % Plot numerical solution
    figure;
    contourf(linspace(0, 1, nx), linspace(0, 1, ny), phi', 20);
    colorbar;
    title('Numerical Solution');
    xlabel('x');
    ylabel('y');
        
    % Plot analytical solution
    figure;
    contourf(linspace(0, 1, nx), linspace(0, 1, ny), phi_analytical, 20);
    colorbar;
    title('Analytical Solution');
    xlabel('x');
    ylabel('y');
end

% Plot CPU run time vs total number of grid points
total_points = grids.^2;
figure;
plot(total_points, run_times, '-o');
xlabel('Total Number of Grid Points');
ylabel('CPU Run Time (seconds)');
title('CPU Run Time vs Total Number of Grid Points');

function phi = diffusion_equation(nx, ny, dx, dy)
    % Create a 2D grid of nodes
    x = linspace(0, 1, nx);
    y = linspace(0, 1, ny);
    [X, Y] = meshgrid(x, y);
    
    % Initialize the solution array
    phi = zeros(nx, ny);

    % Apply boundary conditions
    phi(:, 1) = 500 * exp(-50 * (1 + Y(:, 1).^2));
    phi(:, end) = 100 * (1 - Y(:, end)) + 500 * exp(-50 * (Y(:, end).^2));
    phi(1, :) = 100 * X(1,:) .* (1 - Y(1, :)) + 500 * exp(-50 * ((1 - X(1,:)).^2));
    phi(end, :) = 500 * exp(-50 * ((1 - X(end,:)).^2 + 1));

    % Create the finite difference matrix
    A = zeros(nx*ny, nx*ny);
    b = zeros(nx*ny, 1);
    
    for i = 1:nx
        for j = 1:ny
            if i == 1 || i == nx || j == 1 || j == ny
                A((i-1)*ny + j, (i-1)*ny + j) = 1;
                b((i-1)*ny + j) = phi(i, j);
            else
                A((i-1)*ny + j, (i-1)*ny + j) = -4;
                A((i-1)*ny + j, (i-2)*ny + j) = 1.0;
                A((i-1)*ny + j, i*ny + j) = 1.0;
                A((i-1)*ny + j, (i-1)*ny + j-1) = 1.0;
                A((i-1)*ny + j, (i-1)*ny + j+1) = 1.0;

                S_phi = 50000 * exp(-50 * ((1 - X(i, j))^2 + Y(i, j)^2)) * (100 * ((1 - X(i, j))^2 + Y(i, j)^2) - 2);
                b((i-1)*ny + j) = S_phi * dx^2;
                
            end
        end
    end

    % Solve the system using Gaussian elimination
    phi_flat = gaussian_elimination(A, b);
    phi = reshape(phi_flat, [nx, ny]);
end

function x = gaussian_elimination(A, b)
    n = length(A);
    % Forward Elimination
    for i = 1:n-1
        for k = i+1:n
            c = -A(k, i) / A(i, i);
            A(k, i:end) = A(k, i:end) + c * A(i, i:end);
            b(k) = b(k) + c * b(i);
        end
    end

    % Back Substitution
    x = zeros(n, 1);
    x(n) = b(n) / A(n, n);
    for i = n-1:-1:1
        sum = 0;
        for j = i+1:n
            sum = sum + A(i, j) * x(j);
        end
        x(i) = (b(i) - sum) / A(i, i);
    end
    
end
    
function phi_analytical = analytical_solution(X, Y)
    phi_analytical = 500 * exp(-50 * ((1 - X).^2 + Y.^2)) + 100 * X .* (1 - Y);
end

function diffusion_analysis_adi()
    clc;

    % Parameters
    n = 41;
    m = 81;
    x = linspace(0, 1, n);
    y = linspace(0, 1, m);
    dx = 1/(n-1);
    dy = 1/(m-1);

    % Source term function
    S = @(x, y) 50000 * exp(-50 * ((1 - x)^2 + y^2)) * (100 * ((1 - x)^2 + y^2) - 2);

    % Boundary conditions
    phi_left = @(y) 500 * exp(-50 * (1 + y.^2));           % Left boundary (x = 0)
    phi_right = @(y) 100 * (1 - y) + 500 * exp(-50 * y.^2); % Right boundary (x = 1)
    phi_bottom = @(x) 100 * x + 500 * exp(-50 * (1 - x).^2); % Bottom boundary (y = 0)
    phi_top = @(x) 500 * exp(-50 * ((1 - x).^2 + 1));       % Top boundary (y = 1)

    % Initial guess for phi
    phi = zeros(n, m);

    % Apply boundary conditions
    phi(1, :) = phi_left(y);    % Bottom boundary (y = 0)
    phi(n, :) = phi_right(y);   % Top boundary (y = 1)
    phi(:, 1) = phi_bottom(x);  % Left boundary (x = 0)
    phi(:, m) = phi_top(x);     % Right boundary (y = 1)

    % Tolerance and maximum iterations
    tolerance = 1e-6;
    max_iterations = 10000;

    % ADI method main diagonals and off-diagonals for TDMA solver
    main_diag_x = -2 * (1 + (dx/dy)^2) * ones(n-2, 1);
    sub_diag_x = ones(n-3, 1);
    super_diag_x = ones(n-3, 1);

    main_diag_y = -2 * (1 + (dy/dx)^2) * ones(m-2, 1);
    sub_diag_y = ones(m-3, 1);
    super_diag_y = ones(m-3, 1);

    % Residual arrays
    residuals_row = [];
    residuals_col = [];
    residuals_adi = [];

    phi_row = phi;
    phi_col = phi;

    % Perform ADI method
    [phi, residuals_adi] = adi(phi, x, y, n, m, dx, dy, S, main_diag_x, sub_diag_x, super_diag_x, main_diag_y, sub_diag_y, super_diag_y, tolerance, max_iterations, residuals_adi);

    % perform row sweep
    for iter = 1:max_iterations

        % X-direction sweep (row-wise)
        [phi_row, res_row] = row_sweep(phi_row, n, m, x, y, dx, dy, S, main_diag_x, sub_diag_x, super_diag_x);

        % Total ADI residual calculation after both sweeps
        residuals_row = [residuals_row; res_row];

        % Check for convergence
        if res_row < tolerance
            fprintf('Converged in %d iterations\n', iter);  % row iteration count
            break;
        end

        if iter == max_iterations
            warning('Method did not converge in the maximum number of iterations');
        end
    end

    % perform col sweep
    for iter = 1:max_iterations

        % Y-direction sweep (column-wise)
        [phi_col, res_col] = col_sweep(phi_col, n, m, x, y, dx, dy, S, main_diag_y, sub_diag_y, super_diag_y);

        % Total ADI residual calculation after both sweeps
        residuals_col = [residuals_col; res_col];

        % Check for convergence
        if res_col < tolerance
            fprintf('Converged in %d iterations\n', 2 * iter);  % ADI iteration count
            break;
        end

        if iter == max_iterations
            warning('Method did not converge in the maximum number of iterations');
        end
    end

    % Plotting the result
    [X, Y] = meshgrid(x, y);
    figure;
    contourf(X, Y, phi', 20); % Transpose phi for correct contour plot
    colorbar;
    xlabel('x');
    ylabel('y');
    title('Contour Plot of \phi for the 2D Steady-State Diffusion Equation');

    % Plot residuals
    figure;
    semilogy(residuals_row, 'r', 'DisplayName', 'Row-wise Sweep');
    hold on;
    semilogy(residuals_col, 'g', 'DisplayName', 'Column-wise Sweep');
    semilogy(residuals_adi, 'b', 'DisplayName', 'ADI Method');
    hold off;
    xlabel('Iteration');
    ylabel('Residual (log scale)');
    title('Residual vs. Iteration for Row-wise, Column-wise, and ADI Methods');
    legend('show');
    grid on;

    % Plot residuals with linear scale
    figure;
    plot(residuals_row, 'r', 'DisplayName', 'Row-wise Sweep');
    hold on;
    plot(residuals_col, 'g', 'DisplayName', 'Column-wise Sweep');
    plot(residuals_adi, 'b', 'DisplayName', 'ADI Method');
    hold off;
    xlabel('Iteration');
    ylabel('Residual');
    title('Residual vs. Iteration for Row-wise, Column-wise, and ADI Methods');
    legend('show');
    grid on;

end

function [phi, res] = row_sweep(phi, n, m, x, y, dx, dy, S, main_diag_x, sub_diag_x, super_diag_x)
    res = 0;
    for j = 2:m-1
        rhs = zeros(n-2, 1);
        for i = 2:n-1
            xi = x(i);
            yj = y(j);
            rhs(i-1) = S(xi, yj) * dx^2 - (phi(i, j+1) + phi(i, j-1)) * (dx/dy)^2;
            if i == 2
                rhs(i-1) = rhs(i-1) - phi(i-1, j);
            elseif i == n-1
                rhs(i-1) = rhs(i-1) - phi(i+1, j);
            end
        end
        new_phi = tdma_solver(sub_diag_x, main_diag_x, super_diag_x, rhs);
        res = res + norm(new_phi - phi(2:n-1, j), inf);
        phi(2:n-1, j) = new_phi;
    end
end

function [phi, res] = col_sweep(phi, n, m, x, y, dx, dy, S, main_diag_y, sub_diag_y, super_diag_y)
    res = 0;
    for i = 2:n-1
        rhs = zeros(m-2, 1);
        for j = 2:m-1
            xi = x(i);
            yj = y(j);
            rhs(j-1) = S(xi, yj) * dy^2 - (phi(i+1, j) + phi(i-1, j)) * (dy/dx)^2;
            if j == 2
                rhs(j-1) = rhs(j-1) - phi(i, j-1);
            elseif j == m-1
                rhs(j-1) = rhs(j-1) - phi(i, j+1);
            end
        end
        new_phi = tdma_solver(sub_diag_y, main_diag_y, super_diag_y, rhs);
        res = res + norm(new_phi - phi(i, 2:m-1)', inf);
        phi(i, 2:m-1) = new_phi;
    end
end

function [phi, residuals_adi] = adi(phi, x, y, n, m, dx, dy, S, main_diag_x, sub_diag_x, super_diag_x, main_diag_y, sub_diag_y, super_diag_y, tolerance, max_iterations, residuals_adi)
    for iter = 1:max_iterations
        phi_old = phi; % Store old values of phi for convergence checking

        % X-direction sweep (row-wise)
        [phi, res_row] = row_sweep(phi, n, m, x, y, dx, dy, S, main_diag_x, sub_diag_x, super_diag_x);

        % Total ADI residual calculation after both sweeps
        residuals_adi = [residuals_adi; res_row];

        % Check for convergence
        if res_row < tolerance
            fprintf('Converged in %d iterations\n', 2 * iter - 1);  % ADI iteration count
            break;
        end

        if iter == max_iterations
            warning('Method did not converge in the maximum number of iterations');
        end

        % Y-direction sweep (column-wise)
        [phi, res_col] = col_sweep(phi, n, m, x, y, dx, dy, S, main_diag_y, sub_diag_y, super_diag_y);

        % Total ADI residual calculation after both sweeps
        residuals_adi = [residuals_adi; res_col];

        % Check for convergence
        if res_col < tolerance
            fprintf('Converged in %d iterations\n', 2 * iter);  % ADI iteration count
            break;
        end

        if iter == max_iterations
            warning('Method did not converge in the maximum number of iterations');
        end
    end
end


% TDMA solver function
function x = tdma_solver(a, b, c, d)
    % TDMA solver
    % a - sub-diagonal (length n-1)
    % b - main diagonal (length n)
    % c - super-diagonal (length n-1)
    % d - right-hand side (length n)
    % x - solution (length n)

    n = length(b);  % number of equations
    
    % Forward elimination
    for i = 2:n
        w = a(i-1) / b(i-1);
        b(i) = b(i) - w * c(i-1);
        d(i) = d(i) - w * d(i-1);
    end
    
    % Backward substitution
    x = zeros(n, 1);
    x(n) = d(n) / b(n);
    for i = n-1:-1:1
        x(i) = (d(i) - c(i) * x(i+1)) / b(i);
    end
end